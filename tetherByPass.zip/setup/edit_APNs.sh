#!/system/bin/sh

export PATH=/tmp:$PATH:/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
exec 0>&1

set +e

busybox mount -o remount,rw /system
if [ $? != 0 ] ; then exit 1
fi
busybox mount -o remount,rw /data
if [ $? != 0 ] ; then exit 1
fi

# Variable declarations
DB=/data/data/com.android.providers.telephony/databases/telephony.db
ARCH=$(getprop ro.product.cpu.abilist)
SQLITE=

if [[ $ARCH == *"arm64-v8a"* ]]
then
  echo "SQLite will be arm64-v8a";
  SQLITE=/tmp/sqlite3/arm64-v8a/sqlite3-dynamic
fi;
if [[ $ARCH == *"armeabi"* ]]
then
  echo "SQLite will be armeabi";
  SQLITE=/tmp/sqlite3/armeabi/sqlite3-dynamic
fi;
if [[ $ARCH == *"armeabi-v7a"* ]]
then
  echo "SQLite will be armeabi-v7a";
  SQLITE=/tmp/sqlite3/armeabi-v7a/sqlite3-dynamic
fi;
if [[ $ARCH == *"mips"* ]]
then
  echo "SQLite will be mips";
  SQLITE=/tmp/sqlite3/mips/sqlite3-dynamic
fi;
if [[ $ARCH == *"mips64"* ]]
then
  echo "SQLite will be mips64";
  SQLITE=/tmp/sqlite3/mips64/sqlite3-dynamic
fi;
if [[ $ARCH == *"x86"* ]]
then
  echo "SQLite will be x86";
  SQLITE=/tmp/sqlite3/x86/sqlite3-dynamic
fi;
if [[ $ARCH == *"x86_64"* ]]
then
  echo "SQLite will be x86_64";
  SQLITE=/tmp/sqlite3/x86_64/sqlite3-dynamic
fi;

if [[ ! $SQLITE ]]
then
	echo "SQLite will be none, leaving";
	exit;
fi;

#$SQLITE $BD