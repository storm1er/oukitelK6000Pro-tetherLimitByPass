# Hi everyone

First mod from me, be fair ;)
XDA Link : http://forum.xda-developers.com/android/software-hacking/mod-hotspot-unlocker-t3518558


> DISCLAIMER :
> I'm not responsible for any damage, brick, silent alarm or nuclear attack on your phone !
> Be careful and make a backup before if you're afraid !

Here the problem : my provider allow me to use hotspot, but my phone don't.
I managed to resolve this thanks to http://forum.xda-developers.com/nexus-6/general/how-to-unlock-tethering-android-4-4-to-t3227206.
But I thought a little flashable zip could help some others people :D
So i made one, originally for my Oukitel K6000 Pro, but i thinks it may apply for most of android 6+ (maybe 5+ ... anyone can confirm ?)

> TL;DR
> If your hotspot doesn't work and you don't know why, try these, it's not magical, but it may work ;)

You can download the zip from here
Feel free to copy / edit my mod, pull requesting, issues etc ... as long as it has my name on it ...

Required :
- Your phone
- Your head
- A backup of your phone (just in case)
- An USB cable
- A recovery (tested only on TWRP but CWM should work no problem)

Installation :
- Push zip to phone
- Reboot phone to recovery
- Flash tetherByPass.zip
- Reboot
- Try ;)

You shouldn't need to clean cache/dalvik, or mount system (or data) before flashing.
Everything is done in script, but feel free to do it if you want =)
