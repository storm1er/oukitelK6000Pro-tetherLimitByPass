# oukitelK6000Pro-tetherLimitByPass
disable tether's provider's limitation on Oukitel k6000 pro
