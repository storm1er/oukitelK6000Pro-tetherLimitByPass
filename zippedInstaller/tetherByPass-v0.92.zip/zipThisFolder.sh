#!/bin/bash

zip -r tetherByPass.zip . -x ".*" -x "*/.*"
